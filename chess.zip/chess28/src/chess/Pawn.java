/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * Pawn piece class.
 *  
 * @author Sanam Suthar 
 * @author Kishan Patel
 *
 */
public class Pawn extends Piece {
	
	/** Different pieceColor of pieces. */
	public String pieceColor;
	
	/**
	 * To string.
	 *
	 * @return toString method specifying the pieceColor and piece.
	 */
	public String toString() {
		return pieceColor+"p ";
	}
	
	/**
	 * Instantiates a new pawn.
	 *
	 * @param pieceColor Different pieceColor of pieces
	 */
	public Pawn(String pieceColor) {
		super(pieceColor);
		this.pieceColor = pieceColor;
	}

	/**
	 *  
	 * This will return the updated chessboard after moving the piece.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return This is the final chessboard
	 */
	@Override
	public Piece[][] move(String insert, Piece[][] chessBoard) {
		
	    String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
		
		Piece initializePiece = chessBoard[56 - initializeRank][initializeFile-'a'];
		
		try {
			if (chessBoard[56 - lastRank][lastFile-'a'] == null && white && initializeRank+1 == lastRank && initializeFile-1 == lastFile && !chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant||				
					chessBoard[56 - lastRank][lastFile-'a'] == null && !white && initializeRank-1 == lastRank && initializeFile-1 == lastFile && chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant){
				chessBoard[56 - initializeRank][initializeFile-'a'-1] = null;
			}
			else if (chessBoard[56 - lastRank][lastFile-'a'] == null && white && initializeRank+1 == lastRank && initializeFile+1 == lastFile && !chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant ||
					chessBoard[56 - lastRank][lastFile-'a'] == null && !white && initializeRank+1 == lastRank && initializeFile+1 == lastFile && chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant){
				chessBoard[56 - initializeRank][initializeFile-'a'+1] = null;
			}
		}catch(Exception e) {
			
		}
		chessBoard[56 - lastRank][lastFile-'a'] = initializePiece;
		chessBoard[56 - initializeRank][initializeFile-'a'] = null;
		
		if (white && lastRank == '8')
			promote(insert, lastFile, lastRank, chessBoard, "w");
		if (!white && lastRank == '1')
			promote(insert, lastFile, lastRank, chessBoard, "b");
		
		return chessBoard;
	}
	
	/**
	 * Promote.
	 *
	 * @param insert users insert has been received
	 * @param lastFile this is the column of destination
	 * @param lastRank this is the row of destination
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @param pieceColor color of the piece
	 */
	public void promote(String insert, char lastFile, char lastRank, Piece[][] chessBoard, String pieceColor) {
		String[] args = insert.split(" ");
		if (args.length == 3) {
			switch(args[2])
			{
				case "q":
					chessBoard[56 - lastRank][lastFile-'a'] = (new Queen(pieceColor));
					return;
				case "b":
					chessBoard[56 - lastRank][lastFile-'a'] = (new Bishop(pieceColor));
					return;
				case "n":
					chessBoard[56 - lastRank][lastFile-'a'] = (new Knight(pieceColor));
					return;
				case "r":
					chessBoard[56 - lastRank][lastFile-'a'] = (new Rook(pieceColor));
					return;
			}
		}
		else
			chessBoard[56 - lastRank][lastFile-'a'] = (new Queen(pieceColor));
	}
	
	/**
	 * This will return a boolean after checking whether the move it implements is true or not.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean.	This will be true if the pawn moves to specified area and false otherwise
	 */
	@Override
	public boolean isValid(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
				
		if (initializeFile == lastFile) {
				
			if (white && initializeRank+1 == lastRank && chessBoard[56 - lastRank][lastFile-'a'] == null){
				return true;
			}
			if (!white && initializeRank-1 == lastRank && chessBoard[56 - lastRank][lastFile-'a'] == null){
				return true;
			}

			if (white && initializeRank == '2' && initializeRank+2 == lastRank && chessBoard[56 - lastRank + 1][lastFile-'a'] == null && chessBoard[56 - lastRank][lastFile-'a'] == null){
				return true;
			}

			if (!white && initializeRank == '7' && initializeRank-2 == lastRank  && chessBoard[56 - lastRank - 1][lastFile-'a'] == null && chessBoard[56 - lastRank][lastFile-'a'] == null){
				return true;
			}
		}

			try {
				if (chessBoard[56 - lastRank][lastFile-'a'] == null && white && initializeRank+1 == lastRank && initializeFile-1 == lastFile && !chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant){
						return true;				
				}
				else if (chessBoard[56 - lastRank][lastFile-'a'] == null && !white && initializeRank+1 == lastRank && initializeFile+1 == lastFile && chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant){
					return true;	
			    }
				else if (chessBoard[56 - lastRank][lastFile-'a'] == null && white && initializeRank+1 == lastRank && initializeFile+1 == lastFile && !chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant){
						return true;					
				}
				else if (chessBoard[56 - lastRank][lastFile-'a'] == null && !white && initializeRank-1 == lastRank && initializeFile-1 == lastFile && chessBoard[56 - initializeRank][lastFile-'a'].white && chessBoard[56 - initializeRank][lastFile-'a'].enpassant){
						return true;				
				}
			}catch(Exception e) {
			}

		if (initializeFile+1 == lastFile && chessBoard[56 - lastRank][lastFile-'a'] != null) {
			if (white && initializeRank+1 == lastRank && !chessBoard[56 - lastRank][lastFile-'a'].white){
				return true;
			}
			if (!white && initializeRank-1 == lastRank && chessBoard[56 - lastRank][lastFile-'a'].white){
				return true;
			}
		}
		else if (initializeFile - 1 == lastFile && chessBoard[56 - lastRank][lastFile-'a'] != null) {
			if (white && initializeRank+1 == lastRank && !chessBoard[56 - lastRank][lastFile-'a'].white){
				return true;
			}
			if (!white && initializeRank-1 == lastRank && chessBoard[56 - lastRank][lastFile-'a'].white){
				return true;
			}
		}
		return false;
	}

}
