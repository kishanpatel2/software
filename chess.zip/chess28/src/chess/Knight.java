/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * Knight piece class 
 *  
 * @author Sanam Suthar 
 * @author Kishan Patel
 *
 */
public class Knight extends Piece {
	
	/** Different pieceColor of the pieces. */
	public String pieceColor;

	/**
	 * To string.
	 *
	 * @return toString method specifying the pieceColor and piece.
	 */
	public String toString() {
		return pieceColor+"N ";
	}
	
	/**
	 * Instantiates a new knight.
	 *
	 * @param pieceColor Color of the piece.
	 */
	public Knight(String pieceColor) {
		super(pieceColor);
		this.pieceColor = pieceColor;
	}
	
	/**
	 * This will return a boolean after checking whether the move it implements is true or not.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean.	This will be true if the knight moves to specified area and false otherwise
	 */
	@Override
	public boolean isValid(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
						
		if (Math.abs(initializeFile - lastFile) == 1 && Math.abs(initializeRank - lastRank) == 2 && chessBoard[56 - lastRank][lastFile-'a'] == null) {
			return true;
		}
		
		else if (Math.abs(initializeFile - lastFile) == 1 && Math.abs(initializeRank - lastRank) == 2 && 
				chessBoard[56 - lastRank][lastFile-'a'].white != chessBoard[56 - initializeRank][initializeFile-'a'].white) {
			return true;
		}
		
		else if (Math.abs(initializeFile - lastFile) == 2 && Math.abs(initializeRank - lastRank) == 1 && chessBoard[56 - lastRank][lastFile-'a'] == null) {
			return true;
		}
		
		else if (Math.abs(initializeFile - lastFile) == 2 && Math.abs(initializeRank - lastRank) == 1 && 
				chessBoard[56 - lastRank][lastFile-'a'].white != chessBoard[56 - initializeRank][initializeFile-'a'].white) {
			return true;
		}
		
		return false;
		
	}

	/**
	 *  
	 * This will return the updated chessboard after moving the piece.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return This is the final chessboard
	 */
	@Override
	public Piece[][] move(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
		
		Piece initializePiece = chessBoard[56 - initializeRank][initializeFile-'a'];
		chessBoard[56 - lastRank][lastFile-'a'] = initializePiece;
		chessBoard[56 - initializeRank][initializeFile-'a'] = null;
				
		return chessBoard;
	}
}
