/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * Queen piece class
 *  
 * @author Sanam Suthar
 * @author Kishan Patel
 *
 */

public class Queen extends Piece{

	/** Different pieceColor of pieces. */
	public String pieceColor;

	/**
	 * To string.
	 *
	 * @return toString method specifying the pieceColor and piece.
	 */
	public String toString() {
		return pieceColor+"Q ";
	}
	
	/**
	 * Instantiates a new queen.
	 *
	 * @param pieceColor Different pieceColor of pieces
	 */
	public Queen(String pieceColor) {
		super(pieceColor);
		this.pieceColor = pieceColor;
	}
	
	/**
	 * Check if obstacle on path is either true or false.
	 *
	 * @param initializeFile This is the column of the initial piece.
	 * @param initializeRank This is the row of the initial piece.
	 * @param lastFile this is the column of destination
	 * @param lastRank this is the row of destination
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean. This will be true if the obstacles exist, will be false otherwise
	 */
	public boolean hasObstacle(char initializeFile, char initializeRank, char lastFile, char lastRank, Piece[][] chessBoard) {
		int loadRank = 56-initializeRank;
		int rankLast = 56-lastRank;
		int loadFile = initializeFile-'a';
		int fileLast = lastFile-'a';
		int differenceInRank = loadRank - rankLast;
		int differenceInFile = loadFile - fileLast;
	
		if (Math.abs(differenceInRank) == Math.abs(differenceInFile)) {

		if (differenceInFile < 0 && differenceInRank > 0) {
			int rank = loadRank-1;
			for (int f = loadFile+1; f < fileLast; f++) {
				if (chessBoard[rank][f] != null)
					return true;
				rank--;
			}
		}

		if (differenceInFile > 0 && differenceInRank > 0) {
			int rank = loadRank - 1;
			for (int f = loadFile-1; f > fileLast; f--) {
				if (chessBoard[rank][f] != null)
					return true;
				rank--;
			}
		}
 
		if (differenceInFile < 0 && differenceInRank < 0) {
			int rank = loadRank + 1;
			for (int f = loadFile+1; f < fileLast; f++) {
				if (chessBoard[rank][f] != null)
					return true;
				rank++;
			}
		}

		if (differenceInFile > 0 && differenceInRank < 0) {
			int rank= loadRank + 1;
			for (int f = loadFile-1; f > fileLast; f--) {
				if (chessBoard[rank][f] != null)
					return true;
				rank++;
			}
		}	
	}

		if (loadRank != rankLast && loadFile == fileLast) {
			if (loadRank > rankLast) 
				for (int rank = loadRank-1; rank > rankLast; rank--) {
					if (chessBoard[rank][loadFile] != null)
						return true;
				}
			if (loadRank < rankLast) 
				for (int rank = loadRank+1; rank < rankLast; rank++) {
					if (chessBoard[rank][loadFile] != null)
						return true;
				}
			}

		if (loadRank == rankLast && loadFile != fileLast) {
			if (initializeFile > lastFile)
				for (int f = loadFile-1; f > fileLast; f--) {
					if (chessBoard[loadRank][f] != null) {
						return true;
					}
				}
			if (initializeFile < lastFile)
				for (int f = loadFile+1; f < fileLast; f++) {
					if (chessBoard[loadRank][f] != null) {
						return true;
					}
		}
	}
		return false;
	}
	
	/**
	 *  
	 * This will return the updated chessboard after moving the piece.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return This is the final chessboard
	 */
	@Override
	public Piece[][] move(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
	
		Piece initializePiece = chessBoard[56 - initializeRank][initializeFile-'a'];
	
		chessBoard[56 - lastRank][lastFile-'a'] = initializePiece;
		chessBoard[56 - initializeRank][initializeFile-'a'] = null;
	
		return chessBoard;
	}
	
	/**
	 * This will return a boolean after checking whether the move it implements is true or not.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean.	This will be true if the queen moves to specified area and false otherwise
	 */
	@Override
	public boolean isValid(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
	
		if ((initializeFile == lastFile && initializeRank != lastRank) || (initializeFile != lastFile && initializeRank == lastRank) || Math.abs(initializeFile - lastFile) == Math.abs(initializeRank - lastRank)) { 
			if(!hasObstacle(initializeFile, initializeRank, lastFile, lastRank, chessBoard)) {
				if (chessBoard[56-lastRank][lastFile-'a'] == null) {
					return true;
				}
				if (chessBoard[56-lastRank][lastFile-'a'].white != chessBoard[56-initializeRank][initializeFile-'a'].white) {
					return true;
				}
			}
		}
		return false;
	}
		
}