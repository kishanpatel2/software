/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * Bishop piece class .
 *
 * @author Sanam Suthar
 * @author Kishan Patel
 */
public class Bishop extends Piece {

	/** Different color of the pieces. */
	public String pieceColor;
	
	/**
	 * To string.
	 *
	 * @return toString method for the color and piece.
	 */
	public String toString() {
		return pieceColor+"B ";
	}

	/**
	 * Instantiates a new bishop.
	 *
	 * @param pieceColor the piece color
	 */
	public Bishop(String pieceColor) {
		super(pieceColor);
		this.pieceColor = pieceColor;
	}
	
	/**
	 *  
	 * This will return the updated chessboard after moving the piece.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return This is the final chessboard
	 */
	@Override
	public Piece[][] move(String insert, Piece[][] chessBoard) {
		String[] args = insert.split(" ");
		char initilizeFile = args[0].charAt(0);
		char initilizeRank = args[0].charAt(1);
		char lastRank = args[1].charAt(1);
		char lastFile = args[1].charAt(0);
		Piece iPiece = chessBoard[56 - initilizeRank][initilizeFile-'a'];
		chessBoard[56 - lastRank][lastFile-'a'] = iPiece;
		chessBoard[56 - initilizeRank][initilizeFile-'a'] = null;
		return chessBoard;
	}
	
	/**
	 * This will return a boolean after checking whether the move it implements is true or not.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean.	This will be true if the bishop moves to specified area and false otherwise
	 */
	@Override
	public boolean isValid(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		String[] args = insert.split(" ");
		char initilizeFile = args[0].charAt(0);
		char initilizeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
		int a = Math.abs(initilizeFile - lastFile);
		int b = Math.abs(initilizeRank - lastRank);
	
		if (a == b) { 
			if(!hasObstacle(initilizeFile, initilizeRank, lastFile, lastRank, chessBoard)) {
				if (chessBoard[56-lastRank][lastFile-'a'].white != chessBoard[56-initilizeRank][initilizeFile-'a'].white)
					return true;
				if (chessBoard[56-lastRank][lastFile-'a'] == null)
					return true;
			}
		}
	return false;
	}
	
	/**
	 * Check if obstacle on path is either true or false.
	 *
	 * @param initilizeFile the initilize file
	 * @param initilizeRank the initilize rank
	 * @param lastFile this is the column of destination
	 * @param lastRank this is the row of destination
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean. This will be true if the obstacles exist, will be false otherwise
	 */
	public boolean hasObstacle(char initilizeFile, char initilizeRank, char lastFile, char lastRank, Piece[][] chessBoard) {
		int loadRank = 56-initilizeRank;
		int rankLast = 56-lastRank;
		int loadFile = initilizeFile-'a';
		int fileLast = lastFile-'a';
		int differenceInFile = loadFile - fileLast;
		int differenceInRank = loadRank - rankLast;
		
		if (Math.abs(differenceInRank) == Math.abs(differenceInFile)) {

			if (differenceInFile < 0 && differenceInRank > 0) {
				int rank = loadRank-1;
				for (int f = loadFile+1; f < fileLast; f++) {
					if (chessBoard[rank][f] != null)
						return true;
					rank--;
				}
			}
	
			if (differenceInFile > 0 && differenceInRank > 0) {
				int rank = loadRank-1;
				for (int f = loadFile-1; f > fileLast; f--) {
					if (chessBoard[rank][f] != null)
						return true;
					rank--;
				}
			}

			if (differenceInFile > 0 && differenceInRank < 0) {
				int rank= loadRank+1;
				for (int f = loadFile-1; f > fileLast; f--) {
					if (chessBoard[rank][f] != null)
						return true;
					rank++;
				}
			}
			if (differenceInFile < 0 && differenceInRank < 0) {
				int rank = loadRank+1;
				for (int f = loadFile+1; f < fileLast; f++) {
					if (chessBoard[rank][f] != null)
						return true;
					rank++;
				}
			}
		}
		return false;
	}
}