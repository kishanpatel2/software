/**
 *
 */
package chess;
import java.util.Scanner;

// TODO: Auto-generated Javadoc
/**
 * This will run the chess match.
 *
 * @author Sanam Suthar
 * @author Kishan Patel
 */
public class Chess {

/** The chess game. */
private static Board chess;

/** The game is in play. */
static boolean inPlay = true;

/** The scanner for moves. */
private static Scanner scan = new Scanner(System.in);

	/**
	 * Main method starts the game by calling start method.
	 *
	 * @param args arguments
	 */
	public static void main(String[] args) {
		start();
	}
	
	/**
	 * Beginning of a game.
	 */
	public static void start() {
		String insert;
		boolean correctMove;
		boolean correctInput;
		chess = new Board();
		chess.initializePieces();
		chess.showBoard();
		while (!chess.complete()) {
			
			if (chess.moveWhite()) {
				if(chess.checkWhite())
					if (chess.checkmate()) {
						System.out.println("Checkmate");
						System.out.println("Black wins");
						System.exit(0);
					}
					else {
						System.out.println("Check");
					}
				if(!chess.checkWhite())
					if (chess.checkmate()) {
						System.out.println("Stalemate");
						System.out.println("draw");
						System.exit(0);
					}
				System.out.print("White's move: ");
			}
			else {
				if(chess.checkBlack())
					if (chess.checkmate()) {
						System.out.println("Checkmate");
						System.out.println("White wins");
						System.exit(0);
					}else {
						System.out.println("Check");
					}
				if(!chess.checkBlack())
					if (chess.checkmate()) {
						System.out.println("Stalemate");
						System.out.println("draw");
						System.exit(0);
					}
				System.out.print("Black's move: ");	
			}
			insert = scan.nextLine().toLowerCase();
			correctInput = isValidInput(insert);
			correctMove = false;
			
			if (correctInput) {
				correctMove = chess.isValid(insert);
			}
			else {
				while(!correctMove || !correctInput) {
					if (!correctInput) {
						System.out.println("Illegal move, try again");
					}
					else if (!correctMove) {
						System.out.println("Illegal move, try again");
					}
					if (chess.moveWhite()) {
						System.out.print("White's move: ");
					}
					else {
						System.out.print("Black's move: ");	
					}
					insert = scan.nextLine().toLowerCase();
					correctInput = isValidInput(insert);
					correctMove = true;
					if (correctInput) {
						correctMove = chess.isValid(insert);
					}
				}
			}
			if(!correctMove) {	
				System.out.println("Illegal move, try again");
		
			}
			else {
				if(chess.move(insert)) {
					chess.showBoard();
					}
			}
		}
	}
	
	/**
	 * Returns boolean if user insert is valid or not.
	 * 
	 * @param insert		User's insert received.
	 * @return Boolean.	True if insert is valid, false otherwise.
	 * 
	 */
	public static boolean isValidInput(String insert) {
		//Checks to see if player is resigning the chess
		if (insert.equalsIgnoreCase("forfeit"))
		{
			if(chess.moveWhite()){
				System.out.println("Black wins");
			}
			else{
				System.out.println("White wins");
			}
			System.exit(0);
		}

		String[] args = insert.split(" ");
		if (args.length == 3)
			if (args[2].equalsIgnoreCase("draw?"))
				chess.tieYes();
		
		else if (insert.equalsIgnoreCase("draw")){
			if(chess.tyingGame()) {
				System.out.println("draw.");
				System.exit(0);
			}
		}
		
		else if(chess.tyingGame())
		{
			if (!insert.equalsIgnoreCase("draw"))
				chess.tieNo();
		}

		return insert.matches("[abcdefgh][12345678] [abcdefgh][12345678] [qnrb]")
				|| insert.matches("[abcdefgh][12345678] [abcdefgh][12345678] draw[?]")
				|| insert.matches("[abcdefgh][12345678] [abcdefgh][12345678]");
	
	}
}

