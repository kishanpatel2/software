/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * Abstract super class for all Chess pieces.
 * 
 * @author Sanam Suthar 
 * @author Kishan Patel
 * 
 */
public abstract class Piece {
	
	/** The first pawn capture move. */
	boolean enpassant;
	
	/** The has moved. */
	boolean hasMoved;
	
	/** The white. */
	boolean white;
	
	/** The type. */
	String type;
	
	/**
	 * Instantiates a new piece.
	 *
	 * @param color 	Color (white or black) of the piece.
	 */
	public Piece(String color) {
		white = color.equals("w");
		hasMoved = false;
	}
	
	/**
	 * Returns a boolean if piece is white or if is not white.
	 * 
	 * @return Boolean.		True if piece is White, false if piece is black.	
	 *  
	 */
	public boolean white() {
		return white;
	}
	
	/**
	 * Returns boolean after checking if the piece has moved or has not moved.
	 * 
	 * @return Boolean.		True is the piece is moved, false if piece has not moved.
	 * 
	 */
	public boolean hasMoved() {
		return hasMoved;
	}
	
	/**
	 * Returns boolean after checking if the move is valid or not valid.
	 * 
	 * @param input		The user input of coordinates.
	 * @param board 	The game board at the moment.
	 * @return Boolean. True if Piece has valid move, false if piece has not moved.
	 *  
	 */
	public abstract boolean isValid(String input, Piece[][] board);
	
	/** 
	 * Returns board updated with the latest valid move.
	 * 
	 * @param input		The user input of coordinates.
	 * @param board		The game board at the moment.
	 * @return The updated board with latest move.
	 * 
	 */
	public abstract Piece[][] move(String input, Piece[][] board);

}
