/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * Rook piece (castle)
 *  
 * @author Sanam Suthar 
 * @author Kishan Patel
 *
 */

public class Rook extends Piece{
	
	/** Different pieceColor of the pieces. */
	public String pieceColor;
	
	/**
	 * To string.
	 *
	 * @return toString method specifying the pieceColor and piece.
	 */
	public String toString() {
		return pieceColor+"R ";
	}

	/**
	 * Instantiates a new rook.
	 *
	 * @param pieceColor Different pieceColor of the pieces
	 */
	public Rook(String pieceColor) {
		super(pieceColor);
		this.pieceColor = pieceColor;
	}

	/**
	 *  
	 * This will return the updated chessboard after moving the piece.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return This is the final chessboard
	 */
	@Override
	public Piece[][] move(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
		
		Piece initPiece = chessBoard[56 - initializeRank][initializeFile-'a'];

		chessBoard[56 - lastRank][lastFile-'a'] = initPiece;
		chessBoard[56 - initializeRank][initializeFile-'a'] = null;

		return chessBoard;	
		
	}
	
	/**
	 * Check if obstacle on path is either true or false.
	 *
	 * @param initializeFile This is the column of the initial piece.
	 * @param initializeRank This is the row of the initial piece.
	 * @param lastFile this is the column of destination
	 * @param lastRank this is the row of destination
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean. This will be true if the obstacles exist, will be false otherwise
	 */
	public boolean inPath(char initializeFile, char initializeRank, char lastFile, char lastRank, Piece[][] chessBoard) {
		int loadRank = 56-initializeRank;
		int rankLast = 56-lastRank;
		int loadFile = initializeFile-'a';
		int fileLast = lastFile-'a';

		if (loadRank != rankLast && loadFile == fileLast) {
			if (loadRank > rankLast) //up
				for (int r = loadRank-1; r > rankLast; r--)
					if (chessBoard[r][loadFile] != null)
						return true;
			
			if (loadRank < rankLast) //down
				for (int r = loadRank+1; r < rankLast; r++)
					if (chessBoard[r][loadFile] != null)
						return true;
		}

		if (loadRank == rankLast && loadFile != fileLast) {
			if (initializeFile > lastFile) //left
				for (int f = loadFile-1; f > fileLast; f--)
					if (chessBoard[loadRank][f] != null)
						return true;
			
		if (initializeFile < lastFile) //right
			for (int f = loadFile+1; f < fileLast; f++)
				if (chessBoard[loadRank][f] != null)
					return true;
		}
		return false;
	}
	
	/**
	 * This will return a boolean after checking whether the move it implements is true or not.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean.	This will be true if the Rook moves to specified area and false otherwise
	 */
	@Override
	public boolean isValid(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
		
		if ((initializeFile == lastFile && initializeRank != lastRank) || (initializeFile != lastFile && initializeRank == lastRank)) { 
			if(!inPath(initializeFile, initializeRank, lastFile, lastRank, chessBoard)) {
				if (chessBoard[56-lastRank][lastFile-'a'] == null)
					return true;
				if (chessBoard[56-lastRank][lastFile-'a'].white != chessBoard[56-initializeRank][initializeFile-'a'].white)
					return true;
			}
		}
		return false;
	}
}
