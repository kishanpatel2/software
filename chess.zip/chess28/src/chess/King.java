/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * King piece Class
 *  
 * @author Sanam Suthar 
 * @author Kishan Patel
 *
 */
public class King extends Piece {
	
	/** Different Color of pieces. */
	public String pieceColor;
	
	/**
	 * To string.
	 *
	 * @return toString method specifying the pieceColor and piece.
	 */
	public String toString() {
		return pieceColor+"K ";
	
	}

	/**
	 * Instantiates a new king.
	 *
	 * @param pieceColor Different color of pieces
	 */
	public King(String pieceColor) {
		super(pieceColor);
		this.pieceColor = pieceColor;
	}

	/**
	 *  
	 * This will return the updated chessboard after moving the piece.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return This is the final chessboard
	 */
	@Override
	public Piece[][] move(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
		
		if (!hasMoved() && lastFile == 'g' && (lastRank-48 == 1 || lastRank-48 == 8)
			&& chessBoard[56 - lastRank][7] instanceof Rook
			&& !chessBoard[56 - lastRank][7].hasMoved()
			&& chessBoard[56 - lastRank][7].white() == white()){			
			if((chessBoard[7][5] == null && chessBoard[7][6] == null) || (chessBoard[0][5] == null && chessBoard[0][6] == null)) 
				chessBoard = castle(initializeRank, 7, chessBoard);
		}
		else if (!hasMoved() && lastFile == 'c' && (lastRank-48 == 1 || lastRank-48 == 8)
			&& chessBoard[56 - lastRank][0] instanceof Rook
			&& !chessBoard[56 - lastRank][0].hasMoved()
			&& chessBoard[56 - lastRank][0].white() == white()) {
			
			if((chessBoard[7][1] == null && chessBoard[7][2] == null && chessBoard[7][3] == null) || (chessBoard[0][1] == null && chessBoard[0][2] == null && chessBoard[0][3] == null)) 
				chessBoard = castle(initializeRank, 0, chessBoard);		
		}
		else {
			Piece initPiece = chessBoard[56 - initializeRank][initializeFile-'a'];
		
			chessBoard[56 - lastRank][lastFile-'a'] = initPiece;
			chessBoard[56 - initializeRank][initializeFile-'a'] = null;
		}
		return chessBoard;
	}
	
	/**
	 * Returns an updated chessBoard
	 *  
	 * @param initializeRank This is the row of the initial piece.
	 * @param fileRooke		Rook File - column of destination pieceRook piece.
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return This is the updated chessboard
	 * 
	 */
	public Piece[][] castle (char initializeRank, int fileRooke, Piece[][] chessBoard) {
		Piece pieceKing = chessBoard[56 - initializeRank][4];
		Piece pieceRook = chessBoard[56 - initializeRank][fileRooke];
		
		if (fileRooke == 7) {
			chessBoard[56 - initializeRank][6] = (pieceKing);
			chessBoard[56 - initializeRank][5] = (pieceRook);
			chessBoard[56 - initializeRank][7] = (null);
			chessBoard[56 - initializeRank][4] = (null);
		}
		if (fileRooke == 0) {
			chessBoard[56 - initializeRank][2] = (pieceKing);
			chessBoard[56 - initializeRank][3] = (pieceRook);
			chessBoard[56 - initializeRank][0] = (null);
			chessBoard[56 - initializeRank][1] = (null);
			chessBoard[56 - initializeRank][4] = (null);
		}
		
		return chessBoard;
	}
	
	/**
	 * This will return a boolean after checking whether the move it implements is true or not. Includes the castling move.
	 *
	 * @param insert users insert has been received
	 * @param chessBoard This is the original chessboard holding the pieces
	 * @return Boolean.	This will be true if the king moves to specified area and false otherwise
	 */
	@Override
	public boolean isValid(String insert, Piece[][] chessBoard) {
		// TODO Auto-generated method stub
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char lastFile = args[1].charAt(0);
		char lastRank = args[1].charAt(1);
		int iR = Math.abs(initializeRank - lastRank);
		int iF = Math.abs(initializeFile - lastFile);

		if (iR <= 1 && iF <= 1 && chessBoard[56 - lastRank][lastFile-'a'] == null){
			return true;
		}

		if (iR <= 1 && iF <= 1) {
			if((white && !chessBoard[56 - lastRank][lastFile-'a'].white) || (!white && chessBoard[56 - lastRank][lastFile-'a'].white)){
				return true;
			}
		}
		if (!chessBoard[56 - initializeRank][initializeFile - 'a'].hasMoved()){
			if(lastFile == 'c' && (56 - lastRank == 0 || 56 - lastRank == 7)
					&& chessBoard[56 - lastRank][0] instanceof Rook
					&& !chessBoard[56 - lastRank][0].hasMoved()
					&& chessBoard[56 - lastRank][0].white() == white()){
				if((chessBoard[7][1] == null && chessBoard[7][2] == null && chessBoard[7][3] == null) || (chessBoard[0][1] == null && chessBoard[0][2] == null && chessBoard[0][3] == null)) 
					return true;
			}
			if(lastFile == 'g' && (56 - lastRank == 0 || 56 - lastRank == 7)
					&& chessBoard[56 - lastRank][7] instanceof Rook
					&& !chessBoard[56 - lastRank][7].hasMoved()
					&& chessBoard[56 - lastRank][7].white() == white()){
				if((chessBoard[7][5] == null && chessBoard[7][6] == null) || (chessBoard[0][5] == null && chessBoard[0][6] == null)) 
					return true;	
			}
			
		}
		return false;
	}

}