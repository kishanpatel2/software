/**
 * 
 */
package chess;

// TODO: Auto-generated Javadoc
/**
 * This class represents the functions and chess chessBoard.
 *
 * @author Sanam Suthar
 * @author Kishan Patel
 */
public class Board {
	
	/** Move completed. */
	private boolean complete;
	
	/** The move white. */
	private boolean moveWhite;
	
	/** The check white. */
	private boolean checkWhite;
	
	/** The check black. */
	private boolean checkBlack;
	
	/** The draw available. */
	private boolean drawAvailable;
	
	/** The chess board. */
	public static Piece[][] chessBoard;
	
	/**
	 * Instantiates a new board.
	 */
	public  Board() {
	}
	
	/**
	 * this method puts all of the pieces on the chessBoard.
	 */
	public void initializePieces() {
		
		complete = false;
		moveWhite = true;
		checkWhite = false;
		checkBlack = false;
		drawAvailable = false;
		chessBoard = new Piece[8][8];
		
		chessBoard[1][0] = new Pawn("b");
		chessBoard[1][1] = new Pawn("b");
		chessBoard[1][2] = new Pawn("b");
		chessBoard[1][3] = new Pawn("b");
		chessBoard[1][4] = new Pawn("b");
		chessBoard[1][5] = new Pawn("b");
		chessBoard[1][6] = new Pawn("b");
		chessBoard[1][7] = new Pawn("b");
		chessBoard[6][0] = new Pawn("w");
		chessBoard[6][1] = new Pawn("w");
		chessBoard[6][2] = new Pawn("w");
		chessBoard[6][3] = new Pawn("w");
		chessBoard[6][4] = new Pawn("w");
		chessBoard[6][5] = new Pawn("w");
		chessBoard[6][6] = new Pawn("w");
		chessBoard[6][7] = new Pawn("w");	
		chessBoard[0][2] = new Bishop("b");
		chessBoard[0][5] = new Bishop("b");
		chessBoard[7][2] = new Bishop("w");
		chessBoard[7][5] = new Bishop("w");
		chessBoard[0][4] = new King("b");
		chessBoard[7][4] = new King("w");
		chessBoard[0][3] = new Queen("b");
		chessBoard[7][3] = new Queen("w");
		chessBoard[0][0] = new Rook("b");
		chessBoard[0][7] = new Rook("b");
		chessBoard[7][0] = new Rook("w");
		chessBoard[7][7] = new Rook("w");
		chessBoard[0][1] = new Knight("b");
		chessBoard[0][6] = new Knight("b");
		chessBoard[7][1] = new Knight("w");
		chessBoard[7][6] = new Knight("w");
		
	}
	
	/**
	 * this method outputs all the possibilities.
	 */
	public static void showBoard() {
        System.out.println();
		for(int i = 0 ; i < 8; i++){
	        for(int j = 0 ; j < 8; j++){
	        	if(chessBoard[i][j] == null) {
		            if((i % 2 == 0 && j % 2 == 0) || (i % 2 == 1 && j % 2 == 1))
		                System.out.print("   ");
		            else
		                System.out.print("## ");
	        	}
	        	else
	        	{
	        		System.out.print(chessBoard[i][j]);
	        	}
	        }
	        System.out.println(8 - i);
	    }
	    System.out.println(" a  b  c  d  e  f  g  h \n");
	}
	
	/**
	 *  
	 * Returns boolean if piece can move or not.
	 *
	 * @param insert the next move
	 * @return This is the final chess board
	 */
	public boolean move(String insert) {
		String[] args = insert.split(" ");
		char initializeFile = args[0].charAt(0);
		char initializeRank = args[0].charAt(1);
		char finalFile = args[1].charAt(0);
		char finalRank = args[1].charAt(1);
		
		Piece[][] clone = clone(chessBoard);
		clone = clone[56 - initializeRank][initializeFile-'a'].move(insert, clone);	
	
		if (correctPiece(clone,"")) {
			
			System.out.println("Illegal move, try again");
			return false;
		}
		else {
			chessBoard = chessBoard[56 - initializeRank][initializeFile-'a'].move(insert, chessBoard);	
			if (correctEnemyPosition()) {
				swapTurn();
				if(moveWhite)
					checkWhite = true;	
				else
					checkBlack = true;
			}
			else {
				try{
					for(int i = 0 ; i<8 ; i++){
				        for(int j = 0 ; j<8 ; j++){
				        	if(chessBoard[i][j] instanceof Pawn) 
					           chessBoard[i][j].enpassant = false;
				        }
				    }
					if (chessBoard[56 - finalRank][finalFile-'a'] instanceof Pawn && Math.abs(initializeRank - finalRank) == 2){
							chessBoard[56 - finalRank][finalFile-'a'].enpassant = true;
					}
				}catch (Exception e) {
					System.out.println(e.toString());
				}
				swapTurn();
			}
		}
		return true;
	}
	
	/**
	 * Returns boolean after checking if the move is valid or not.
	 * 
	 * @param insert users insert has been received
	 * @return This is the final chessboard
	 * 
	 */
	public boolean isValid(String insert) {
		String[] args = insert.split(" ");
		String initilizePosition = args[0];
		String lastPosition = args[1];
		char initializeRank = initilizePosition.charAt(1);
		char initializeFile = initilizePosition.charAt(0);
		
		
		// if the position is the same / there's no piece in the selected place / the piece is not the correct player's piece
		if (initilizePosition.equals(lastPosition)) {
			return false;
		}
		else if (chessBoard[56 - initializeRank][initializeFile-'a'].white() != moveWhite()) {
			return false;
		}
		else if (chessBoard[56 - initializeRank][initializeFile-'a'] == null) {
			return false;
		}
		else 
			return chessBoard[56 - initializeRank][initializeFile-'a'].isValid(insert, chessBoard);
	}
	
	/**
	 * Returns boolean for check mate.
	 * @return Boolean.	True if check mate, false otherwise
	 * 
	 */
	public boolean checkmate() {
		int correctMove = 0;
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				char rank = (char) (56 - i);
				char file = (char) (j + 'a');
				String yourPiece = file + "" + rank;

				if(chessBoard[i][j] != null ) {
					if((moveWhite && chessBoard[i][j].white) || (!moveWhite && !chessBoard[i][j].white)) {
						
						for(int r = 0 ; r<8 ; r++){
							for(int f = 0 ; f<8 ; f++){

								char alternativeRank = (char) (56 - r);
								char alternativeFile = (char) (f + 'a');
								String differentPlacement = alternativeFile + "" + alternativeRank;
								String insert = yourPiece +" "+ differentPlacement;
								Piece[][] clone = clone(chessBoard);
								
								if(clone[i][j].isValid(insert, clone)) {
										
									clone = clone[i][j].move(insert, clone);

									if (!correctPiece(clone, "expir")) {
										correctMove++;
									}
								}
								
							}
						}
						
					}
			    }
			}
		}
		return (correctMove == 0);
	}

	/**
	 * Returns boolean after checking if the check is valid or not.
	 *
	 * @param t variable that holds temporary location of piece
	 * @param expir test string that holds the value
	 * @return This is the final chess board
	 */
	public boolean correctPiece(Piece[][] t, String expir) {
		
		boolean makeCheck = false;
		String locationKing = "";
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(t[i][j] != null && t[i][j] instanceof King) {
					if((moveWhite && t[i][j].white) || (!moveWhite && !t[i][j].white)) {
						char rank = (char) (56 - i);
						char file = (char) (j + 'a');
						locationKing = file + "" + rank;	
					}
			    }
			}
		}
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(t[i][j] != null) {
					if((!moveWhite && t[i][j].white) || (moveWhite && !t[i][j].white)) {
						char rank = (char) (56 - i);
						char file = (char) (j + 'a');
						String opponentPiece = file + "" + rank;
						if (t[i][j].isValid(opponentPiece +" "+ locationKing, t)) {
							return true;
						}
						else makeCheck = false;	
					}
			    }
			}
		}	
		if(expir.equals("")) {
			if(moveWhite)
				checkWhite = false;
			else
				checkBlack = false;
		}
		return makeCheck;
	}
	
	/**
	 * Returns boolean checking if person is in check or is not in check.
	 * @return Boolean.	True if opp in check, false if not in check
	 * 
	 */
	public boolean correctEnemyPosition() {
		
		boolean makeCheck = false;
		String locationOppKing = "";
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(chessBoard[i][j] != null && chessBoard[i][j] instanceof King) {
					if((moveWhite && !chessBoard[i][j].white) || (!moveWhite && chessBoard[i][j].white)) {
						char rank = (char) (56 - i);
						char file = (char) (j + 'a');
						locationOppKing = file + "" + rank;	
					}
			    }
			}
		}
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(chessBoard[i][j] != null) {
					if((moveWhite && chessBoard[i][j].white) || (!moveWhite && !chessBoard[i][j].white)) {
						char rank = (char) (56 - i);
						char file = (char) (j + 'a');
						String yourPiece = file + "" + rank;
						if (chessBoard[i][j].isValid(yourPiece +" "+ locationOppKing, chessBoard)) {
							return true;
						}
						else makeCheck = false;	
					}
			    }
			}
		}		
		return makeCheck;
	}
	
	/**
	 * Returns the copied Piece[][].
	 * @param chessBoard User's insert received.
	 * @return Returns the temporary Piece[][].
	 */
	public Piece[][] clone (Piece[][] chessBoard){
		Piece[][] piece = new Piece[8][8];
		for(int i = 0; i < 8; i++){
	        for(int j = 0; j < 8; j++){
	        	piece[i][j] = chessBoard[i][j]; 
	        }
	    }
		return piece;
	}
	
	/**
	 * Move white.
	 *
	 * @return Boolean.	True if White's move, false if Black's move.
	 */
	public boolean moveWhite() {
		return moveWhite;
	}
	
	/**
	 * 
	 * Player side is swapped, white pieces cannot move.
	 */
	public void swapTurn() {
		moveWhite = !moveWhite;
	}
	
	/**
	 * Complete.
	 *
	 * @return Boolean.	True if the game is done, false if ongoing.
	 */
	public boolean complete() {
		return complete;
	}
	
	/**
	 * Check white.
	 *
	 * @return Boolean.	True if white is in check, false if white not in check.
	 */
	public boolean checkWhite() {
		return checkWhite;
	}
	
	/**
	 * Check black.
	 *
	 * @return Boolean.	True if black is in check, false if black not in check.
	 */
	public boolean checkBlack() {
		return checkBlack;
	}
	/**
	 *  
	 * @return Boolean.	True if opponent asks for a draw, false otherwise.
	 */
	public boolean tyingGame() {
		return drawAvailable;
	}
	
	/**
	 * Enables the draw option.
	 */
	public void tieYes() {
		drawAvailable = true;
	}
	
	/**
	 * Disables the draw option.
	 */
	public void tieNo() {
		drawAvailable = false;
	}
}

