package songlib;

import java.io.File;
import java.io.PrintWriter;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
/*
 * Written by Bhaumik Patel and Manav Patel
 * 
 */
public class SongLib extends Application {

	@Override
	public void start(Stage stage) throws Exception {
		
		
		//sets the scene from the FXML document
		Parent root = FXMLLoader.load(getClass().getResource("scene.fxml"));
		Scene scene = new Scene(root, 675, 508);
		stage.setScene(scene);
        stage.show();
        
        stage.setOnCloseRequest(event -> {

			// save songs to songs.txt file
			PrintWriter writer;
			try {
				File file = new File("filepath.txt");
				file.createNewFile();
				writer = new PrintWriter(file);

				if (SceneController.oL.isEmpty() == true) {
					writer.println("###");
				} else {
					for (Song s : SceneController.oL) {
						writer.println(s.name);
						writer.println(s.artist);
						writer.println(s.album);
						writer.println(s.year);
					}
				}
				writer.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
        
        
        
       
        
        
        
        
		
	}
	
	public static void main(String args[]) {
		launch(args);
	
	}

}
