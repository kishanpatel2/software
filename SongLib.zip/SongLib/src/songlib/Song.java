package songlib;

import java.util.Comparator;
/*
 * Written by Bhaumik Patel and Manav Patel
 * 
 */
public class Song implements Comparator<Song> {

	String name;
	String artist;
	String album;
	String year;
	
	Song(String name, String artist, String album, String year){
		
		this.name = name;
		this.artist = artist;
		this.album = album;
		this.year = year;
	}
	
	Song(){}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Override
	public int compare(Song o1, Song o2) {
		// TODO Auto-generated method stub
				int song_name_comparison = o1.name.compareToIgnoreCase(o2.name);
				if (song_name_comparison == 0) {
					int song_artist_comparison = o1.artist.compareToIgnoreCase(o2.artist);
					return song_artist_comparison;
				}
				return song_name_comparison;
				
			}
	}
	
	
	
	
	
	

